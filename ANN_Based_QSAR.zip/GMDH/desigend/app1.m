clc
close 
clear all;

load('Mor11u.mat')
load('R5m.mat')
load('RDF150p.mat')

predict = -1.15972 - RDF150p*0.4113 + R5m*7.24492 + Mor11u*1.83991; % predicted pic50 for designed compound by GMDH and raw model of GMDH

figure;
bar(predict);

