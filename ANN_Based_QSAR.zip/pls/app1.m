clc;
clear;
close all;


load('desc.mat')
load('pic50.mat')
load('testdesc.mat')
load('testpic50.mat')
load('desdescribtors.mat')


desc = desc; 
pic50 = pic50; 
desdescribtors = desdescribtors;
% [press,cumpress] = crossval(desc,pic50,'nip','con',70,30);
[press,cumpress] = crossval(desc,pic50,'nip','loo',70);
%[press,cumpress] = crossval(desc,pic50,'mlr','loo');
% [press,cumpress] = crossval(desc,pic50,'sim','rnd',70,3,10);
%figure
%plot(sum(press));

y = 22; % number of principal component(PCs)
[m,ssq,p,q,w,t,u,b] = pls(desc,pic50,y);
predict = desc*m(y,:)'; %predicted train data by PLS

figure
plot(predict,pic50,'s')

cun1 = testdesc*m(y,:)'; % predicted test data by PLS

Errors = abs(predict - pic50);
MSE = mean(Errors.^2); 
RMSE = sqrt(MSE);
ErrorMean = mean(Errors);
ErrorStd = std(Errors);
Errors1 = abs(cun1 - testpic50);
ErrorMean1 = mean(Errors1);

R = corr2(predict, pic50);
R2 = corr2(cun1, testpic50);

predicted_designed_compound = desdescribtors*m(y,:)'; % predicted designed data by PLS

figure 
bar(predicted_designed_compound)
