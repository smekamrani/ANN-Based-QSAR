%% Comparision between ridge regression and MLR
%% 2nd experimental data
clc;
clear;
close all;
%The SFCM temperature and molten glass level data are stored in the file 
%plsdata.mat. The file contains 300 calibration or �training� samples 
%(xblock1 and yblock1) and 200 test samples (xblock2 and yblock2). A
%regression model relating temperature to molten glass level.
load plsdata
x = delsamps(xblock1,[73 167 188 278 279]);
figure;
plot(x.data');
y = delsamps(yblock1,[73 167 188 278 279]);
figure;
plot(y.data);
% preprossecing
meanA=mean(x.data);              % mean centring A_c and c
meanc=mean(y.data);
A_c_m=x.data-repmat(meanA,size(x.data,1),1);
figure;
plot(A_c_m');
c=y.data-repmat(meanc,size(y.data,1),1);
%% MLR(ILS)
bmlr = A_c_m\c; %mlr, calibration step
sx = scale(xblock2.data,meanA);
ymlr = sx*bmlr; %mlr, prediction step
symlr = ymlr+meanc;
figure;
plot(1:200,yblock2.data,'-g',1:200,symlr,'-or')
%% ridge regression
% functions in PLS toolbox
[brr1,theta1] = ridge_pt(A_c_m,c,0.015,31);
[brr2,theta2,cumpress] = ridgecv(A_c_m,c,0.015,31,10);
% prediction step
yrr1 = sx*brr1;
yrr2 = sx*brr2;
syrr1 = yrr1+meanc;
syrr2 = yrr2+meanc;
% comparision in figure
figure;
plot(1:200,yblock2.data,'-g',1:200,symlr,'-or')
hold on;
plot(1:200,syrr1,'*-k',1:200,syrr2,'*-b')
% function in MATLAB
k = 0:1e-5:5e-3;
br_m = ridge(c,A_c_m,k);
yr_m = sx*br_m;
syr_m = ymlr+meanc;
figure;
plot(1:200,yblock2.data,'-g',1:200,syr_m,'-or')


