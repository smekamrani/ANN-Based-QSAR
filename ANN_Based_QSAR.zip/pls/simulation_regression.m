clc;
clear;
close all;
landa=(300:1:688)';
load spec.mat
figure;
plot(landa,S');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1th simulation
% calibration set
c=rand(10,4);
figure;
plot(c,'-*');
A_c=c*S;
A_c=A_c+(.003*max(max(A_c))*randn(size(A_c)));
figure;
plot(A_c','m');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unknown for cls
c_u=rand(1,4);
a_u=c_u*S;
a_u=a_u+(.003*max(max(a_u))*randn(size(a_u)));
save 1th_simulation.mat A_c a_u c_u c
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2nd simulation
% calibration set
c=[rand(10,2) .3*ones(10,1) .5*ones(10,1)];
figure;
plot(c,'-*');
A_c=c*S;
A_c=A_c+(.003*max(max(A_c))*randn(size(A_c)));
figure;
plot(A_c','m');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unknown for ils
c_u=rand(1,4);
a_u=c_u*S;
a_u=a_u+(.003*max(max(a_u))*randn(size(a_u)));
save 2nd_simulation.mat A_c a_u c_u c
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% experimental data
clc;
clear;
close all;
load corn.mat mp6spec propvals; % load corn data set
A_data=mp6spec.data;            % NIR spectra
c_data=propvals.data(:,3);      % protein qualities
lam=[1100:2:2498];
figure;
plot(lam,A_data);
xlabel('wavelength')
rand('seed',1);             % initialise random number generator
ns=length(c_data);
s=ceil(rand(10,1)*ns);      % random selection of 10 samples
A_c=A_data; A_c(s,:)=[];        % calibration set excluding 10 samples
figure;
plot(lam,A_c);
c=c_data; c(s)=[];
A_u=A_data(s,:);            % 'unknown' test samples
c_u_k=c_data(s);            % their 'known' qualities  
