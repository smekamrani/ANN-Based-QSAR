%% pre-processing 
meanA=mean(A_c);              % mean centring A_c and c
meanc=mean(c);
A_c_m=A_c-repmat(meanA,size(A_c,1),1);
figure;
plot(A_c_m');
c=c-repmat(meanc,size(c,1),1);
norm_coef=1./std(A_c_m);     % normalisation of A_c_m
A_c_m=A_c_m*diag(norm_coef);
figure;
plot(A_c_m');
%% cls
s=c\A_c;
cun=s'\a_u';
%% ILS
b=A_c\c;
cun=a_u*b;


